# Pretty Reddit Mobile

Uses the old.reddit url and makes it mobile freindly.

Should work in your current version of firefox app as of Aug 2024

## What it does

This extension includes:

* modest re-styling of the main pages, menus and comment pages.
* swipe left to open the side bar starting right of center
* swipe right to open header menu starting left of center


## this app does not require any special permissions at this time